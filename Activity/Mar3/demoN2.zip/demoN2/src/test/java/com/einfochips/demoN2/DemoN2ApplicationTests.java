package com.einfochips.demoN2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoN2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
